import random
answer = random.randint(1, 101)

print("THIS IS THE OVER/UNDER GAME")
print("YOU HAVE 5 GUESSES TO GUESS A NUMBER BETWEEN 1 AND 100")
print("A NEW NUMBER IS GENERATED EACH TIME YOU PLAY")
print("______________________________________________")
print()

i = 0
while i <= 5:
  guess = input("Enter a guess: ")
  if int(guess) > answer:
    print("YOUR GUESS IS OVER THE ANSWER")
    print()
    i += 1
    if i == 5:
      print("GAME OVER THE ANSWER IS " + str(answer))
      i = 10
      if i >= 6:
        print()
        print("BETTER LUCK NEXT TIME")
  elif int(guess) < answer:
    print("YOUR GUESS IS UNDER THE ANSWER")
    print()
    i += 1
    if i == 5:
      print("GAME OVER THE ANSWER IS " + str(answer))
      i = 10
      if i >= 6:
        print()
        print("BETTER LUCK NEXT TIME")
  elif int(guess) == answer:
    print("CORRECT")
    i = 10
    if i >= 6:
      print("YOU WON!")


